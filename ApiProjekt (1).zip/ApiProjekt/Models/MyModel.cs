namespace ApiProjekt.Models
{
    public class ProstyModel
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public string Surname { get; set; }

        public string Email { get; set; }

        public bool IsRemote { get; set; }
    }
}